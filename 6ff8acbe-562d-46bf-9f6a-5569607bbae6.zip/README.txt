Downloaded by "Download All Images" extension

Page: https://preview.themeforest.net/item/proffer-fundraising-charity-html-template/full_screen_preview/29039056?clickid=VO50IOyl0xyNWtfxnTS7fUdWUkAwAdWAJVWDV40&iradid=275988&iradtype=ONLINE_TRACKING_LINK&irgwc=1&irmptype=mediapartner&irpid=1223214&mp_value1=&utm_campaign=af_impact_radius_1223214&utm_medium=affiliate&utm_source=impact_radius
Date: 1/13/2023, 5:55:37 PM

Name, Link
----------
envato_market-a5ace93f8482e885ae008eb481b9451d379599dfed2486.svg, https://public-assets.envato-static.com/assets/logos/envato_market-a5ace93f8482e885ae008eb481b9451d379599dfed24868e52b6b2d66f5cf633.svg
logos-6f8a015ab6d9602102f6c4dde38bf1a128f2647f20b76023c4793c.png, https://public-assets.envato-static.com/assets/generated_sprites/logos-6f8a015ab6d9602102f6c4dde38bf1a128f2647f20b76023c4793c2d3d86e57c.png
common-14f8bc60470b39265fe5c01e92035209bd04b91cd7da99d59ca3c.png, https://public-assets.envato-static.com/assets/generated_sprites/common-14f8bc60470b39265fe5c01e92035209bd04b91cd7da99d59ca3ccd9de5eac62.png
logo.png, https://themegeniuslab.com/html/proffer-v2-cp/assets/images/logo.png
img-1.jpg, https://themegeniuslab.com/html/proffer-v2-cp/assets/images/shop/mini-cart/img-1.jpg
apple-touch-icon-72x72-precomposed.png, https://public-assets.envato-static.com/icons/themeforest.net/apple-touch-icon-72x72-precomposed.png
img-2.jpg, https://themegeniuslab.com/html/proffer-v2-cp/assets/images/shop/mini-cart/img-2.jpg
apple-touch-icon-114x114-precomposed.png, https://public-assets.envato-static.com/icons/themeforest.net/apple-touch-icon-114x114-precomposed.png
apple-touch-icon-144x144-precomposed.png, https://public-assets.envato-static.com/icons/themeforest.net/apple-touch-icon-144x144-precomposed.png
apple-touch-icon-precomposed.png, https://public-assets.envato-static.com/icons/themeforest.net/apple-touch-icon-precomposed.png
target.jpg, https://themegeniuslab.com/html/proffer-v2-cp/assets/images/target.jpg
img-3.jpg, https://themegeniuslab.com/html/proffer-v2-cp/assets/images/causes/img-3.jpg
img-4.jpg, https://themegeniuslab.com/html/proffer-v2-cp/assets/images/causes/img-4.jpg
img-5.jpg, https://themegeniuslab.com/html/proffer-v2-cp/assets/images/causes/img-5.jpg
img-1.jpg, https://themegeniuslab.com/html/proffer-v2-cp/assets/images/causes/img-1.jpg
img-2.jpg, https://themegeniuslab.com/html/proffer-v2-cp/assets/images/causes/img-2.jpg
img-2.jpg, https://themegeniuslab.com/html/proffer-v2-cp/assets/images/events/img-2.jpg
img-3.jpg, https://themegeniuslab.com/html/proffer-v2-cp/assets/images/events/img-3.jpg
img-1.jpg, https://themegeniuslab.com/html/proffer-v2-cp/assets/images/events/img-1.jpg
img-3.png, https://themegeniuslab.com/html/proffer-v2-cp/assets/images/partners/img-3.png
img-4.png, https://themegeniuslab.com/html/proffer-v2-cp/assets/images/partners/img-4.png
img-5.png, https://themegeniuslab.com/html/proffer-v2-cp/assets/images/partners/img-5.png
img-6.png, https://themegeniuslab.com/html/proffer-v2-cp/assets/images/partners/img-6.png
img-1.png, https://themegeniuslab.com/html/proffer-v2-cp/assets/images/partners/img-1.png
img-2.png, https://themegeniuslab.com/html/proffer-v2-cp/assets/images/partners/img-2.png
cta-s1-pic.jpg, https://themegeniuslab.com/html/proffer-v2-cp/assets/images/cta-s1-pic.jpg
img-1.jpg, https://themegeniuslab.com/html/proffer-v2-cp/assets/images/blog/img-1.jpg
img-2.jpg, https://themegeniuslab.com/html/proffer-v2-cp/assets/images/blog/img-2.jpg
img-3.jpg, https://themegeniuslab.com/html/proffer-v2-cp/assets/images/blog/img-3.jpg
img-1.jpg, https://themegeniuslab.com/html/proffer-v2-cp/assets/images/instagram/img-1.jpg
img-2.jpg, https://themegeniuslab.com/html/proffer-v2-cp/assets/images/instagram/img-2.jpg
img-3.jpg, https://themegeniuslab.com/html/proffer-v2-cp/assets/images/instagram/img-3.jpg
img-4.jpg, https://themegeniuslab.com/html/proffer-v2-cp/assets/images/instagram/img-4.jpg
img-5.jpg, https://themegeniuslab.com/html/proffer-v2-cp/assets/images/instagram/img-5.jpg
img-6.jpg, https://themegeniuslab.com/html/proffer-v2-cp/assets/images/instagram/img-6.jpg
img-7.jpg, https://themegeniuslab.com/html/proffer-v2-cp/assets/images/instagram/img-7.jpg
img-8.jpg, https://themegeniuslab.com/html/proffer-v2-cp/assets/images/instagram/img-8.jpg
img-9.jpg, https://themegeniuslab.com/html/proffer-v2-cp/assets/images/instagram/img-9.jpg
img-10.jpg, https://themegeniuslab.com/html/proffer-v2-cp/assets/images/instagram/img-10.jpg
footer-logo.png, https://themegeniuslab.com/html/proffer-v2-cp/assets/images/footer-logo.png
slide-3.jpg, https://themegeniuslab.com/html/proffer-v2-cp/assets/images/slider/slide-3.jpg
slide-2.jpg, https://themegeniuslab.com/html/proffer-v2-cp/assets/images/slider/slide-2.jpg
slide-1.jpg, https://themegeniuslab.com/html/proffer-v2-cp/assets/images/slider/slide-1.jpg
about.jpg, https://themegeniuslab.com/html/proffer-v2-cp/assets/images/about.jpg
partners-bg.jpg, https://themegeniuslab.com/html/proffer-v2-cp/assets/images/partners/partners-bg.jpg
cta-s2-bg.jpg, https://themegeniuslab.com/html/proffer-v2-cp/assets/images/cta-s2-bg.jpg
